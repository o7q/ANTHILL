#pragma once

#include <vector>

#include "../engine/math/vector.hpp"
#include "../engine/math/bounding_box.hpp"
#include "../engine/window/window.hpp"
#include "../world/world.hpp"
#include "../collision/bounding_box_world/bb_world_collider.hpp"

#include "../weapon/weapon.hpp"

class Entity
{
public:
    Entity(Window &window, const std::vector<World *> &worlds) : m_window(window),
                                                                 m_worlds(worlds),
                                                                 m_bb_collider(m_bounding_box) {}
    virtual ~Entity() {}

    virtual void update();

    virtual void setPosition(float x, float y);
    virtual void move(float x, float y);

    void setXVelocity(float x);
    void setYVelocity(float y);

    void setAimPosition(float x, float y)
    {
        m_aim_position.x = x;
        m_aim_position.y = y;
    }

    Vec2<float> getAimPosition() const { return m_aim_position; }

    void setBoundsSize(int width, int height);

    void setGravityAffected(bool value);
    void setGravityStrength(float gravity);
    void setTerminalVelocity(float terminal_velocity);

    void kill() { m_alive = false; }
    void revive() { m_alive = true; }
    bool isAlive() const { return m_alive; }

    bool onGround() const { return m_on_ground; }

    Vec2<float> getPosition() const { return m_position; }
    Vec2<int> getBoundsSize() const { return m_bounds_size; }

    const BoundingBox &getBoundingBox() const { return m_bounding_box; }

protected:
    virtual void update_x_velocity();
    virtual void update_y_velocity();
    bool check_ground(int y_scan = 1);
    void resolve_world_collision();
    bool in_liquid();

    void update_bounding_box();

protected:
    Window &m_window;
    const std::vector<World *> &m_worlds;

    BoundingBox m_bounding_box;
    BBWorldCollider m_bb_collider;

    Vec2<float> m_position;
    Vec2<float> m_aim_position;
    Vec2<float> m_velocity;
    Vec2<int> m_bounds_size;

    float m_speed = 0.0f;

    // settings
protected:
    float m_terminal_velocity = 5.0f;
    float m_gravity_strength = 0.5f;
    float m_air_resistance = 0.075f;

    bool m_on_ground = false;
    bool m_is_gravity_affected = true;

    bool m_alive = true;
};